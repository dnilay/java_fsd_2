Apache Commons DBCP
===========================

Welcome to the DBCP component of the Apache Commons
project (https://commons.apache.org).

DBCP version 2.5.0 requires JDK 1.8.

DBCP can be built using either Maven or Ant. When building using Ant,
Locations of dependent jars for the Ant build need to be specified in 
build.properties. There is a build.properties.sample file included in the
source distribution.

See https://commons.apache.org/dbcp/ for additional and 
up-to-date information on Commons DBCP.

